<!-- footer content -->
        <footer>
          <div class="pull-right">
            Training Management Software
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- FastClick -->
    <script src="<?php echo base_url() ?>vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url() ?>vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url() ?>vendors/iCheck/icheck.min.js"></script>
    
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url() ?>production/js/moment/moment.min.js"></script>
    <script src="<?php echo base_url() ?>production/js/datepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url() ?>build/js/custom.min.js"></script>
    
  </body>
</html>